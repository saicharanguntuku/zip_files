import boto3
import pymongo
from pymongo import MongoClient
import hashlib

def lambda_handler(event, context):
    # Connect to MongoDB
    MONGO_DB_URL = "mongodb+srv://saicharanguntuku:charan@cluster0.eoxic3r.mongodb.net/"
    CLIENT = MongoClient(MONGO_DB_URL)
    DB = CLIENT["internship"]
    s3urls_info_collection = DB["s3urls_info"]
    document_discrepancy_collection = DB["document_discrepancy_report"]

    # Get the list of S3 object URLs from the bucket
    S3_BUCKET_NAME = "document--repo"
    s3 = boto3.resource("s3")
    bucket = s3.Bucket(S3_BUCKET_NAME)
    s3_object_urls = [f"s3://{S3_BUCKET_NAME}/{obj.key}" for obj in bucket.objects.all()]

    # Get the list of URLs from the s3urls_info collection in MongoDB
    urls_in_mongodb = [doc["aws_s3_url"] for doc in s3urls_info_collection.find({}, {"aws_s3_url": 1})]

    # Find mismatched objects (present in S3 but not in MongoDB) and add them to the discrepancy collection
    mismatched_objects = list(set(s3_object_urls) - set(urls_in_mongodb))
    for mismatched_url in mismatched_objects:
        # Create a unique identifier for the document (MD5 hash of aws_s3_url)
        unique_identifier = hashlib.md5(mismatched_url.encode()).hexdigest()

        # Check if the document with the same unique identifier already exists in the collection
        existing_document = document_discrepancy_collection.find_one({"unique_id": unique_identifier})
        if not existing_document:
            document_discrepancy_collection.insert_one({
                "unique_id": unique_identifier,
                "file_name": mismatched_url.split("/")[-1],
                "aws_s3_url": mismatched_url,
                "is_s3_url_valid": True,
                "does_file_exists": True
            })

    # Find missing objects (present in MongoDB but not in S3) and add them to the discrepancy collection
    missing_objects = list(set(urls_in_mongodb) - set(s3_object_urls))
    for missing_url in missing_objects:
        # Create a unique identifier for the document (MD5 hash of aws_s3_url)
        unique_identifier = hashlib.md5(missing_url.encode()).hexdigest()

        # Check if the document with the same unique identifier already exists in the collection
        existing_document = document_discrepancy_collection.find_one({"unique_id": unique_identifier})
        if not existing_document:
            document_discrepancy_collection.insert_one({
                "unique_id": unique_identifier,
                "file_name": missing_url.split("/")[-1],
                "aws_s3_url": missing_url,
                "is_s3_url_valid": False,
                "does_file_exists": False
            })
    # Disconnect from MongoDB
    CLIENT.close()
    
    response = f"Docs_that_are_in_S3_but_not_in_Database: {len(mismatched_objects)}\n"
    response += f"Docs_that_are_in_Database_but_not_in_S3: {len(missing_objects)}\n"
    response += "Status: Validated Successfully\n"
    
    print(response)
    return response

