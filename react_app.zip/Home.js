import React, { useEffect, useState } from 'react'
import axios from 'axios'
import { Tilt } from 'react-tilt';
function Home() {
    const [re,setRe]=useState(0)
    useEffect(()=>{
        if(re==1){
            let q=document.getElementById("mm")
            /* let y=document.createElement("table")
            y.setAttribute("class","tabel3")
            let trr=document.createElement("tr")
            let tdd=document.createElement("td") */
            let d=document.createElement("div")
            d.className="tabel3"
            d.id="tabel3"
            let h1=document.createElement("h2")
            let ter=document.createTextNode("Click on this link to validate the documents")
            let t=document.createElement("a")
            t.href="https://fmtrcl5xlb5xymp5sbok2ktqfe0bdbzn.lambda-url.us-east-1.on.aws/"
            t.target="_blank"
            //t.setAttribute("class","tabel3")
            let ta=document.createTextNode("https://fmtrcl5xlb5xymp5sbok2ktqfe0bdbzn.lambda-url.us-east-1.on.aws/")
            h1.appendChild(ter)
            d.appendChild(h1)
            t.appendChild(ta)
            /* tdd.appendChild(t)
            trr.appendChild(tdd)
            y.appendChild(trr) */
            d.appendChild(t)
            q.appendChild(d)
        axios.get('https://tcb32azulg.execute-api.us-east-1.amazonaws.com/default/backend').then((res)=>{
            console.log(res.data)
            let mm=document.getElementById('mm');   
            let tabel=document.createElement("table");
            tabel.className="tabel1";
            tabel.setAttribute("id","tabel1")
                let tr=document.createElement("tr")
                let file=document.createTextNode("File Name")//+element.file_name
                let h1=document.createElement("th")
                let S3=document.createTextNode("Is S3 URL Valid")//+element.is_s3_url_valid
                let h2=document.createElement("th")
                let d=document.createTextNode("Does File Exists")//+element.do_file_exists
                let h3=document.createElement("th")
                let a=document.createTextNode("AWS S3 URL")//+element.aws_s3_url
                let h5=document.createElement("th")
                let h4=document.createElement("a")
                h1.appendChild(file)
                h2.appendChild(S3)
                h3.appendChild(d)
                h5.appendChild(a)
                tr.appendChild(h1)
                tr.appendChild(h2)
                tr.appendChild(h3)
                tr.appendChild(h5)
                tabel.appendChild(tr)
            mm.append(tabel)
            res.data.mismatched_and_missing.forEach(element => {
                let tr1=document.createElement("tr")
                let td1=document.createElement("td")
                let tdt=document.createTextNode(element.file_name)
                td1.appendChild(tdt)
                tr1.appendChild(td1)
                let td2=document.createElement("td")
                let tdt2=document.createTextNode(element.is_s3_url_valid)
                td2.appendChild(tdt2)
                tr1.appendChild(td2)
                let td3=document.createElement("td")
                let tdt3=document.createTextNode(element.does_file_exists)
                td3.appendChild(tdt3)
                tr1.appendChild(td3)
                let td4=document.createElement("td")
                let a=document.createElement("a")
                a.href=element.aws_s3_url
                let tdt4=document.createTextNode(element.aws_s3_url)
                a.appendChild(tdt4)
                td4.appendChild(a)
                tr1.appendChild(td4)
                tabel.appendChild(tr1)
            });

        })
         axios.get('https://tcb32azulg.execute-api.us-east-1.amazonaws.com/default/backend').then((res)=>{
            console.log(res.data)
            let mm=document.getElementById('mm');   
            let tabel=document.createElement("table");
            tabel.className="tabel2";
            tabel.id="tabel2"
                let tr=document.createElement("tr")
                let file=document.createTextNode("File Name")//+element.file_name
                let h1=document.createElement("th")
                let S3=document.createTextNode("Is S3 URL Valid")//+element.is_s3_url_valid
                let h2=document.createElement("th")
                let d=document.createTextNode("Does File Exists")//+element.do_file_exists
                let h3=document.createElement("th")
                let a=document.createTextNode("AWS S3 URL")//+element.aws_s3_url
                let h5=document.createElement("th")
                let h4=document.createElement("a")
                h1.appendChild(file)
                h2.appendChild(S3)
                h3.appendChild(d)
                h5.appendChild(a)
                tr.appendChild(h1)
                tr.appendChild(h2)
                tr.appendChild(h3)
                tr.appendChild(h5)
                tabel.appendChild(tr)
            mm.append(tabel)
            res.data.mismatched_and_missing.forEach(element => {
                if(element.is_s3_url_valid===false){
                let tr1=document.createElement("tr")
                let td1=document.createElement("td")
                let tdt=document.createTextNode(element.file_name)
                td1.appendChild(tdt)
                tr1.appendChild(td1)
                let td2=document.createElement("td")
                let tdt2=document.createTextNode(element.is_s3_url_valid)
                td2.appendChild(tdt2)
                tr1.appendChild(td2)
                let td3=document.createElement("td")
                let tdt3=document.createTextNode(element.does_file_exists)
                td3.appendChild(tdt3)
                tr1.appendChild(td3)
                let td4=document.createElement("td")
                let a=document.createElement("a")
                a.href=element.aws_s3_url
                let tdt4=document.createTextNode(element.aws_s3_url)
                a.appendChild(tdt4)
                td4.appendChild(a)
                tr1.appendChild(td4)
                tabel.appendChild(tr1)
                }
            });

        })
    }   

    else
    setRe(1) 
    },[re])

    function new1() {
        const tq = document.getElementById("tabel2");
  if (tq) {
    const si = tq.offsetWidth;
    document.querySelector(".new-container").style.width = si + 150 + "px";
    const sh = tq.offsetHeight;
    document.querySelector(".new-container").style.height = sh + 150 + "px";
  } else {
    console.log("Element with ID 'tabel3' not found.");
  }
        let n1 = document.getElementById("new1");
        if (n1) {
            n1.style.border="1px"
            n1.style.borderStyle="solid"
            n1.style.transitionDuration=".4s"
            n1.style.backgroundColor="white";
        }
    
        let n2 = document.getElementById("new2");
        if (n2) {
            n2.style.opacity=1;
            n2.style.border="1px"
            n2.style.borderStyle="solid"
            n2.style.transitionDuration=".4s"
            n2.style.backgroundColor="rgba(75, 65, 65, 0.589)"
        }
        let n3=document.getElementById("new3")
        if(n3){
            n3.style.border="1px"
            n3.style.borderStyle="solid"
            n3.style.transitionDuration=".4s"
            n3.style.backgroundColor="white";
        }
    
        let tabel1 = document.getElementById("tabel1");
        if (tabel1) {
            tabel1.style.transitionDuration=".4s"
            tabel1.style.opacity = "0";
            tabel1.style.zIndex=0

        }
    
        let tabel2 = document.getElementById("tabel2");
        if (tabel2) {
            tabel2.style.opacity=1;
            tabel2.style.transitionDuration=".9s"
            tabel2.style.left="340px";
            tabel2.style.zIndex=1

        }
        let tabel3=document.getElementById("tabel3");
        if(tabel3){
            tabel3.style.opacity=0;
            tabel3.style.transitionDuration=".4s"
            tabel3.style.zIndex=0

        }
    }
    function new2() {
        const tq = document.getElementById("tabel1");
  if (tq) {
    const si = tq.offsetWidth;
    document.querySelector(".new-container").style.width = si + 150 + "px";
    const sh = tq.offsetHeight;
    document.querySelector(".new-container").style.height = sh + 150 + "px";
  } else {
    console.log("Element with ID 'tabel3' not found.");
  }
        let n1 = document.getElementById("new2");
        if (n1) {
            n1.style.transitionDuration=".4s"
            n1.style.border = "1px";
            n1.style.borderStyle="solid"
            n1.style.backgroundColor="white";
        }
    
        let n2 = document.getElementById("new1");
        if (n2) {
            n2.style.border="1px"
            n2.style.borderStyle = "solid";
            n2.style.transitionDuration=".4s"
            n2.style.backgroundColor="rgba(75, 65, 65, 0.589)";   
        }
        let n3=document.getElementById("new3")
        if(n3){
            n3.style.border="1px"
            n3.style.borderStyle="solid"
            n3.style.transitionDuration=".4s"
            n3.style.backgroundColor="white";
        }
    
        let tabel1 = document.getElementById("tabel1");
        if (tabel1) {
            tabel1.style.display="block"
            tabel1.style.transitionDuration=".4s"
            tabel1.style.opacity = "1";
            tabel1.style.zIndex=1

        }
    
        let tabel2 = document.getElementById("tabel2");
        if (tabel2) {
            tabel2.style.opacity=0;
            tabel2.style.transitionDuration=".9s"
            tabel2.style.right="400px";
            tabel2.style.zIndex=0

        }
        let tabel3=document.getElementById("tabel3");
        if(tabel3){
            tabel3.style.opacity=0;
            tabel3.style.transitionDuration=".4s"
            tabel3.style.zIndex=0

        }
    }
    function new3(){
        const tq = document.getElementById("tabel3");
  if (tq) {
    const si = tq.offsetWidth;
    document.querySelector(".new-container").style.width = si + 100 + "px";
    const sh = tq.offsetHeight;
    document.querySelector(".new-container").style.height = sh + 150 + "px";
    console.log(si,sh)
  } else {
    console.log("Element with ID 'tabel3' not found.");
  }

            let n1 = document.getElementById("new1");
        if (n1) {
            n1.style.border = "1px";
            n1.style.borderStyle="solid"
            n1.style.transitionDuration=".4s"
            n1.style.backgroundColor="white";
        }
        let n3=document.getElementById("new2")
        if(n3){
            n3.style.border="1px"
            n3.style.borderStyle="solid"
            n3.style.borderColor="black"
            n3.style.transitionDuration=".4s"
            n3.style.backgroundColor="white";
        }
        let n2 = document.getElementById("new3");
        if (n2) {
            n2.style.transitionDuration=".4s"
            n2.style.border = "1px";
            n2.style.borderStyle = "solid";
            n2.style.borderColor = "black";
            n2.style.backgroundColor="rgba(75, 65, 65, 0.589)";
        }
    
        let tabel1 = document.getElementById("tabel1");
        if (tabel1) {
            tabel1.style.transitionDuration=".4s"
            tabel1.style.opacity = "0";
            tabel1.style.zIndex=0

        }
    
        let tabel2 = document.getElementById("tabel2");
        if (tabel2) {
            tabel2.style.opacity=0;
            tabel2.style.transitionDuration=".9s"
            tabel2.style.left="500px";
            tabel2.style.zIndex=0

        }
        let tabel3=document.getElementById("tabel3");
        if(tabel3){
            tabel3.style.opacity=1;
            tabel3.style.transitionDuration=".9s"
            tabel3.style.zIndex=1
        }
    }
    
        function m(){
            window.location.href='../Missing'
        }

  return (
    <div id="home">
      <div className="home">
        {/* Add the new-container wrapper */}
        <div className="new-container" id="new">
          <a className="new3" id="new3" onClick={new3}>
            <h1>Validate</h1>
          </a>
          <a className="new1" id="new1" onClick={new2}>
            <h1>Unreferenced Objects</h1>
          </a>
          <a className="new2" id="new2" onClick={new1}>
            <h1>Invalid S3 URLs</h1>
          </a>
        </div>
        <div id="mm"></div>
      </div>
    </div>
  )
}

export default Home