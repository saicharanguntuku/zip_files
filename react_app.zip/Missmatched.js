import React, { useEffect, useState } from 'react'
import axios from 'axios';
import './All.css'
import {Tilt} from 'react-tilt'
function Missmatched() {
    const [re,setRe]=useState(0)
    useEffect(()=>{
    if(re==1){

    
    axios.get('http://localhost:5000/MissMatched').then((res)=>{
        res.data.forEach(element => {
            let file=document.createTextNode("File Name :"+element.file_name)
            let h1=document.createElement("h1")
            let S3=document.createTextNode("is_s3 url valid:"+element.is_s3_url_valid)
            let h2=document.createElement("h1")
            let d=document.createTextNode("do File Exists:"+element.do_file_exists)
            let h3=document.createElement("h1")
            let a=document.createTextNode("AWS s3 url:"+element.aws_s3_url)
            let h5=document.createElement("h1")
            let h4=document.createElement("a")
            h4.href=element.aws_s3_url
            let div=document.createElement("div")
            div.className="box";
            let mm=document.getElementById('mm');
            h1.appendChild(file)
            h2.appendChild(S3)
            h3.appendChild(d)
            h5.appendChild(a)
            h4.appendChild(h5)
            div.appendChild(h1)
            div.appendChild(h2)
            div.appendChild(h3)
            div.appendChild(h4)
            
            mm.append(div)
        });
    })
}   
else
setRe(1) 
},[re])
  return (
    <div  >
        <a href='../' style={{position:"fixed",top:"5px",left:"5px"}} ><button>Back</button></a>
    <center  >
    <h1>Data of MissMatched</h1>
      <div id='mm' >

      </div>
        
    </center>
        
    </div>
  )
}

export default Missmatched