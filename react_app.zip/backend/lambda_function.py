import pymongo
from pymongo import MongoClient
import json
from bson import ObjectId

# Custom JSON encoder to handle ObjectId objects
class CustomJSONEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, ObjectId):
            return str(o)
        return super().default(o)
        
        

def lambda_handler(event, context):
    # Connect to MongoDB
    DB_NAME = "internship"
    COLLECTION="document_discrepancy_report"

    mongodb_url = "mongodb+srv://saicharanguntuku:charan@cluster0.eoxic3r.mongodb.net/"
    client = MongoClient(mongodb_url)
    db = client[DB_NAME]
    document_discrepancy_collection = db[COLLECTION]

    # Retrieve mismatched and missing information from the document_discrepancy_report collection
    mismatched_objects = list(document_discrepancy_collection.find({"is_s3_url_valid": True, "does_file_exists": True}))
    missing_objects = list(document_discrepancy_collection.find({"is_s3_url_valid": False, "does_file_exists": False}))

    # Combine both lists into a single list
    all_discrepancies = mismatched_objects + missing_objects

    # Prepare the response data
    response_data = {
        "mismatched_and_missing" : all_discrepancies
    }

    # Disconnect from MongoDB
    client.close()

    # Return the response data as a JSON string
    return {
        "statusCode": 200,
        "body": json.dumps(response_data, cls=CustomJSONEncoder)
    }
