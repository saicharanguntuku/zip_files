import React from 'react'
import axios from 'axios'
import { BrowserRouter as Router,Switch,Route } from 'react-router-dom'
import Home from './Home'
import Missmatched from './Missmatched'
import Missing from './Missing'
function App() {
  return (
    <div>
      <Router>
        <Switch>
          <Route exact path='/' ><div style={{border:"1px solid black"}} ><Home /></div></Route>
          <Route exact path='/MissMatched' ><Missmatched /></Route>
          <Route exact path='/Missing' ><Missing /></Route>
        </Switch>
      </Router>
    </div>
  )
}

export default App